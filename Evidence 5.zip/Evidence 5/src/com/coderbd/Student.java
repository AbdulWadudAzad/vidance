package com.coderbd;


public class Student {
private String name;
private String password;
private int age ;
private String email;
private String gender;
private String hobby;
private String batch;
private String message;

    public Student() {
    }

    public Student(String name, String password, int age, String email, String gender, String hobby, String batch, String message) {
        this.name = name;
        this.password = password;
        this.age = age;
        this.email = email;
        this.gender = gender;
        this.hobby = hobby;
        this.batch = batch;
        this.message = message;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getGender() {
        return gender;
    }

    public String getHobby() {
        return hobby;
    }

    public String getBatch() {
        return batch;
    }

    public String getMessage() {
        return message;
    }

    
    
    
    
    
}
